package micro

//go:generate ./.github/generate.sh
